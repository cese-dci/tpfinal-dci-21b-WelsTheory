## Archivos Kicad ##

En este directorio debería ir:

* Archivos de proyecto.
* Esquemático.
* PCB.
* Modelos  3D.
* Bibliotecas de símbolos y huellas externas (si son necesarios).
